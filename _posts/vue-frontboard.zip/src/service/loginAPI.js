const getUserInfo = (userId, userPw) => {
    const reqData = {
        'userId': userId,
        'userPw': userPw
    }

    return {
        'data': {
            'userId': reqData.userId,
            'userToken': 'user_test_token',
            'userRole': 'ADM'
        }
    }
}

export default {
    async doLogin (userId, userPw) {
        try {
            const getUserInfoPromise = getUserInfo(userId, userPw);
            const [userInfoResponse] = await Promise.all([getUserInfoPromise]);
            if (userInfoResponse.data.length === 0) {
                return 'notFound';
            } else {
                localStorage.setItem('user_token', userInfoResponse.data.userToken);
                localStorage.setItem('user_role', userInfoResponse.data.userRole);
                return userInfoResponse;
            }
        } catch (err) {
            console.error(err);
        }
    }
}