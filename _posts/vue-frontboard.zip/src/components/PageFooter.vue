<!-- PageFotter.vue -->
<template>
    <hr />
    <footer>여기는 footer 자리입니다.</footer>
</template>

<script>
export default {

}
</script>

<style scoped>
</style>