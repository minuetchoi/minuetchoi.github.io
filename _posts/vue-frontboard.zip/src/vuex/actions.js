import { USER_ID, IS_AUTH, ERROR_STATE } from './mutation_types'
import loginAPI from '../service/loginAPI'

let setUserId = ( {commit}, data) => {
    commit(USER_ID, data);
}

let setErrorState = ( {commit}, data) => {
    commit(ERROR_STATE, data);
}

let setIsAuth = ( {commit}, data) => {
    commit(IS_AUTH, data);
}

// 백앤드에서 반환한 결과값을 가지고 로그인 성공 혹은 실패 여부를 vuex에 넣어준다.
let processResponse = (store, loginResponse) => {
    switch (loginResponse) {
        case 'notFound':
            setErrorState(store, 'Wrong ID or Password')
            setIsAuth(store, false);
            break;
        default:
            setUserId(store, loginResponse.userId);
            setErrorState(store, '')
            setIsAuth(store, true);
    }
}

export default {
    async login(store, {userId, userPw}) {
        let loginResponse = await loginAPI.doLogin(userId, userPw);
        processResponse(store, loginResponse);
        return store.getters.getIsAuth;
    }
}