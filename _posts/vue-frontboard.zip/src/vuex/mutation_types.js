export const USER_ID = 'USER_ID';
export const ERROR_STATE = 'ERROR_STATE';
export const IS_AUTH = 'IS_AUTH';