package com.example.vuebackboard.api.repository;

import com.example.vuebackboard.api.model.PagableResponse;
import com.example.vuebackboard.api.model.Request;
import com.example.vuebackboard.api.model.Response;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface BoardMapper {
    PagableResponse<Response> findBoardList(Request request);

    Response findBoardById(Long id);

    int insertBoard(Request request);

    int updateBoard(Request request);

    void deleteBoard(Long id);
}
