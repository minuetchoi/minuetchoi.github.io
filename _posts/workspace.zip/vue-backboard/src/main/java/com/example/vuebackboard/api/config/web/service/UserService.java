package com.example.vuebackboard.api.config.web.service;

import com.example.vuebackboard.api.config.web.repository.UserMapper;
import com.example.vuebackboard.api.model.Request;
import com.example.vuebackboard.api.model.Response;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
@Service
public class UserService implements UserDetailsService {

    private final UserMapper userMapper;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        List<GrantedAuthority> authorities = new ArrayList<>();

        Request request = new Request();
        request.put("userId", username);
        Response user = userMapper.findUserById(request);

        if (username.equals((String) user.get("userId"))) {
            authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
        }

        return new User((String) user.get("userId"), (String) user.get("userPw"), authorities);
    }
}
