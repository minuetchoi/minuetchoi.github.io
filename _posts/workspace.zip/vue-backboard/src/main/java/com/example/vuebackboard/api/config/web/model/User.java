package com.example.vuebackboard.api.config.web.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Set;

@Data
@AllArgsConstructor
public class User {

    private Long userId;

    private String username;

    private String password;

    private String nickname;

    private boolean activated;

    private Set<Authority> authorities;
}
