package com.example.vuebackboard.batch;

import com.xxl.job.core.context.XxlJobHelper;
import com.xxl.job.core.handler.annotation.XxlJob;
import org.springframework.stereotype.Service;

/**
 * xuxueli 솔루션을 이동한 배치
 * implementation 'com.xuxueli:xxl-job-core:2.3.1'
 * SampleService
 *
 * @author Administrator
 * @version 1.0.0
 * @date 2023-01-25
 *
 **/

@Service
public class SampleService {

    @XxlJob("sampleJobHandler")
    public void sampleJobhandlerMethod() {
        String str = "이것도 가능합니다.";
        XxlJobHelper.log("여기에 로그를 작성하면 확인할 수 있습니다. {}", str);
    }
}
