package com.example.vuebackboard.api.config.mybatis.interceptor;

import com.example.vuebackboard.api.config.mybatis.model.PageInfo;
import com.example.vuebackboard.api.model.PagableResponse;
import com.example.vuebackboard.api.model.Request;
import com.example.vuebackboard.api.model.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.mapping.ResultMap;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.plugin.Intercepts;
import org.apache.ibatis.plugin.Invocation;
import org.apache.ibatis.plugin.Signature;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;

import java.util.ArrayList;
import java.util.List;


/**
 * @author : Morian
 * @Package : com.example.demo.config.mybatis.interceptor
 * @FileName : QueryInterceptor.java
 * @CreateDate : 2021. 4. 19.
 * @Description : Mybatis가 Interceptor를 상속받은 @Component에 대해서 AutoConfiguration을 해준다.
 * SELECT 쿼리에만 작동하는 것으로 확인
 */

@Slf4j
@Intercepts({@Signature(type = Executor.class, method = "query",
    args = {MappedStatement.class, Object.class, RowBounds.class, ResultHandler.class})})
public class QueryInterceptor implements Interceptor {

    private static String COUNT_ID_SUFFIX = "-Long";

    /**
     * @param ms
     * @return
     * @Method : createCountResultMaps
     * @CreateDate : 2021. 4. 19.
     * @Description : COUNT QUERY 결과를 받기위한 ResultMaps 생성
     */
    private List<ResultMap> createCountResultMaps(MappedStatement ms) {
        List<ResultMap> countResultMaps = new ArrayList<>();

        ResultMap countResultMap =
            new ResultMap.Builder(ms.getConfiguration(), ms.getId() + COUNT_ID_SUFFIX, Long.class, new ArrayList<>())
                .build();
        countResultMaps.add(countResultMap);

        return countResultMaps;
    }


    /**
     * @param ms
     * @return
     * @Method : createCountMappedStatement
     * @CreateDate : 2021. 4. 19.
     * @Description : COUNT QUERY 결과를 받기위한 MappedStatement 생성
     * 속도문제로 개선필요 시 간단히 Map으로 캐싱처리해도 될듯
     */
    private MappedStatement createCountMappedStatement(MappedStatement ms) {
        List<ResultMap> countResultMaps = createCountResultMaps(ms);

        return new MappedStatement.Builder(ms.getConfiguration(), ms.getId() + COUNT_ID_SUFFIX,
            ms.getSqlSource(), ms.getSqlCommandType())
            .resource(ms.getResource())
            .parameterMap(ms.getParameterMap())
            .resultMaps(countResultMaps)
            .fetchSize(ms.getFetchSize())
            .timeout(ms.getTimeout())
            .statementType(ms.getStatementType())
            .resultSetType(ms.getResultSetType())
            .cache(ms.getCache())
            .flushCacheRequired(ms.isFlushCacheRequired())
            .useCache(true)
            .resultOrdered(ms.isResultOrdered())
            .keyGenerator(ms.getKeyGenerator())
            .keyColumn(ms.getKeyColumns() != null ? String.join(",", ms.getKeyColumns()) : null)
            .keyProperty(ms.getKeyProperties() != null ? String.join(",", ms.getKeyProperties()) : null)
            .databaseId(ms.getDatabaseId())
            .lang(ms.getLang())
            .resultSets(ms.getResultSets() != null ? String.join(",", ms.getResultSets()) : null)
            .build();
    }


    /**
     * @param list
     * @param pageInfo
     * @return
     * @Method : createPagableResponse
     * @CreateDate : 2021. 4. 19.
     * @Description : 최종적으로 return할 PagableResponse 생성
     */
    private PagableResponse createPagableResponse(List<Response> list, PageInfo pageInfo) {

        PagableResponse pagableResponse = new PagableResponse();
        pagableResponse.setPageInfo(pageInfo);
        pagableResponse.setList(list);

        return pagableResponse;
    }

    @Override
    public Object intercept(Invocation invocation) throws Throwable {
        try {
            Request request = (Request) invocation.getArgs()[1];
            int page = Integer.parseInt((String) request.get("page"));
            int size = Integer.parseInt((String) request.get("size"));
            int blockSize;
            if (request.get("blockSize") == null) {
                blockSize = 10;
            } else {
                blockSize = Integer.parseInt((String) request.get("blockSize"));
            }
            PageInfo pageInfo = PageInfo.builder().totalCount(-1L).page(page).size(size).blockSize(blockSize).build();
            invocation.getArgs()[2] = pageInfo;

            // 아래주석은 pageInfo를 상속받아 처리하면 인자 2번째에 자동 세팅됨...
            // PageInfo pageInfo = (PageInfo) invocation.getArgs()[2];

            log.debug("■■ QueryInterceptor intercept: Request Parameter가 PageInfo.class를 상속 ■■");

            MappedStatement originalMappedStatement = (MappedStatement) invocation.getArgs()[0];
            MappedStatement countMappedStatement = createCountMappedStatement(originalMappedStatement);

            // COUNT 구하기
            invocation.getArgs()[0] = countMappedStatement;
            List<Long> totalCount = (List<Long>) invocation.proceed();
            pageInfo.setTotalCount((Long) totalCount.get(0));

            // LIST 구하기
            invocation.getArgs()[0] = originalMappedStatement;

            List<Response> list = (List<Response>) invocation.proceed();

            // 페이지 연산
            pageInfo.compute();

            return createPagableResponse(list, pageInfo);

        } catch (ClassCastException e) {
        }

        return invocation.proceed();
    }
}
