package com.example.vuebackboard.api.config.mybatis.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.ibatis.session.RowBounds;

/**
 * @author : Morian
 * @Package : com.example.demo.config.mybatis.model
 * @FileName : PageInfo.java
 * @CreateDate : 2021. 4. 12.
 * @Description : 페이징 처리 상속 모델
 * RowBounds는 StatementInterceptor에서 RowBounds를 가져오기위해 사용
 * 직접적인 접근은 할 수 없음
 * 그리고 return 되는 값에도 offset, limit는 제외
 */

@Data
@Builder
@EqualsAndHashCode(callSuper = false)
@JsonIgnoreProperties({"offset", "limit"})
public class PageInfo extends RowBounds {

    /** 현재 페이지 */
    ;
    protected Integer page;

    /**
     * 페이지당 보여지는 게시글 최대 개수
     */
    protected Integer size;

    /**
     * 총 게시글 수
     */
    protected Long totalCount = -1L; // set이 되지않았다는 의미로 -1

    /**
     * 현재 블럭
     */
    Integer block;

    /**
     * 총 페이지 수
     */
    Integer totalPageCnt;

    /**
     * 총 구간 수
     */
    Integer totalBlockCnt;

    /**
     * 시작 페이지
     */
    Integer startPage;

    /**
     * 마지막 페이지
     */
    Integer endPage;

    /**
     * 이전 구간 마지막 페이지
     */
    Integer prevBlock;

    /**
     * 다음구간 시작 페이지
     */
    Integer nextBlock;

    /**
     * 인덱스
     */
    Integer startIndex;

    /**
     * 블럭 사이즈
     */
    Integer blockSize;

    public void compute() {

        /**
         * 다음 인자는 필수항목
         *
         * totalCount: 총 게시글 수
         * page: 페이지번호
         * size: 페이지당 보여지는 게시글 최대 개수
         * blockSize: 블럭사이즈
         */

        // 총 페이지 수
        totalPageCnt = (int) Math.ceil(getTotalCount() * 1.0 / getSize());

        // 총 블럭수
        totalBlockCnt = (int) Math.ceil(totalPageCnt * 1.0 / getBlockSize());

        // 현재 블럭
        block = (int) Math.ceil((getPage() * 1.0) / getBlockSize());

        // 블럭 시작 페이지
        startPage = ((block - 1) * getBlockSize() + 1);

        // 블럭 마지막 페이지
        endPage = startPage + getBlockSize() - 1;

        // 블럭 마지막 페이지 validation
        if (endPage > totalPageCnt) {
            endPage = totalPageCnt;
        }

        // 이전 블럭 (클릭 시 ,이전 블럭 마지막 페이지)
        prevBlock = (block * getBlockSize()) - getBlockSize();

        // 이전 블럭 validation
        if (prevBlock < 1) {
            prevBlock = 1;
        }

        // 다음 블럭 (클릭 시, 다음 블럭 첫번째 페이지)
        nextBlock = (block * getBlockSize() + 1);

        // 다음 블럭 validation
        if (nextBlock > totalPageCnt) {
            nextBlock = totalPageCnt;
        }

        startIndex = (getPage() - 1) * getSize();
    }
}
