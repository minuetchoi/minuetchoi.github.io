package com.example.vuebackboard.api.config.web.repository;

import com.example.vuebackboard.api.model.Request;
import com.example.vuebackboard.api.model.Response;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface UserMapper {

    Response findUserById(Request request);
}
