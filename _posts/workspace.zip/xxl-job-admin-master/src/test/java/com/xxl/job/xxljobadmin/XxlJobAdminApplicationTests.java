package com.xxl.job.xxljobadmin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XxlJobAdminApplicationTests {

    @Test
    void contextLoads() {
    }

}
