package com.example.vuebackboard.api.config.quartz.job;

import lombok.extern.slf4j.Slf4j;
import org.quartz.*;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@PersistJobDataAfterExecution
@DisallowConcurrentExecution
// @RequiredArgsConstructor 사용x
public class QuartzJob implements Job {

    // private MarketRepository marketRepository;

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {

        log.info("Quartz Job Executed");

        JobDataMap dataMap = context.getJobDetail().getJobDataMap();
        log.info("dataMap date : {}", dataMap.get("date"));
        log.info("dataMap executeCount : {}", dataMap.get("executeCount"));

        // JobDataMap를 통해 Job의 실행 횟수를 받아서 횟수 + 1을 한다.
        int cnt = (int) dataMap.get("executeCount");
        dataMap.put("executeCount", ++cnt);

        // Market 테이블에 현재 시간을 insert 한다.

//        Market market = new Market();
//        market.setName(String.format("%s", dataMap.get("date")));
//        market.setPrice(3000);
//        marketrepository.save(market);

    }
}
