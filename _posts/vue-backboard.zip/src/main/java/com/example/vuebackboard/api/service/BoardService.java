package com.example.vuebackboard.api.service;

import com.example.vuebackboard.api.model.PagableResponse;
import com.example.vuebackboard.api.model.Request;
import com.example.vuebackboard.api.model.Response;
import com.example.vuebackboard.api.repository.BoardMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class BoardService {

    private final BoardMapper mapper;

    public PagableResponse getBoardList(Request request) {
        PagableResponse pagableResponse = mapper.findBoardList(request);
        return pagableResponse;
    }

    public Response getBoard(Long idx) {
        return mapper.findBoardById(idx);
    }

    public Request create(Request request) {
        mapper.insertBoard(request);
        return request;
    }

    public Request update(Request request) {
        mapper.updateBoard(request);
        return request;
    }

    public void delete(Long id) {
        mapper.deleteBoard(id);
    }
}
