/*
페이징 처리를 위해 StatementHandler의 prepare와 query 함수를 사용한다.

public interface StatementHandler {
    Statement prepare(Connection var1, Integer var2) throws SQLException; <- 이것 사용

    void parameterize(Statement var1) throws SQLException;

    void batch(Statement var1) throws SQLException;

    int update(Statement var1) throws SQLException;

    <E> List<E> query(Statement var1, ResultHandler var2) throws SQLException; <- 이것 사용

    <E> Cursor<E> queryCursor(Statement var1) throws SQLException;

    BoundSql getBoundSql();

    ParameterHandler getParameterHandler();
}
*/