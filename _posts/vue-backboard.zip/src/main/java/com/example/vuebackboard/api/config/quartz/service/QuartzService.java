package com.example.vuebackboard.api.config.quartz.service;

import com.example.vuebackboard.api.config.quartz.job.QuartzJob;
import com.example.vuebackboard.api.config.quartz.listener.QuartzJobListener;
import com.example.vuebackboard.api.config.quartz.listener.QuartzTriggerListener;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.quartz.*;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Configuration
@RequiredArgsConstructor
public class QuartzService {

    private final Scheduler scheduler;

    @PostConstruct
    public void init() {
        try {
            // 스케줄러 초기화 -> DB도 클리어
            scheduler.clear();

            // Job리스너 등록
            scheduler.getListenerManager().addJobListener(new QuartzJobListener());

            // Trigger 리스너 등록
            scheduler.getListenerManager().addTriggerListener(new QuartzTriggerListener());

            // Job에 필요한 Parameter 생성
            Map map = new HashMap<>();
            // Job의 실행횟수 및 실행시간
            map.put("executeCount", 1);
            map.put("date", LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));

            // Job생성 및 Scheduler에 등록
            addJob(QuartzJob.class, "QuartzJob", "Quartz Job 입니다.", map, "0/5 * * * * ?");

        } catch (Exception e) {
            log.error("addJob error : {}", e);
        }
    }

    public <T extends Job> void addJob(Class<? extends Job> job, String name, String desc, Map map, String cron) throws SchedulerException {
        JobDetail jobDetail = buildJobDetail(job, name, desc, map);
        Trigger trigger = buildCronTrigger(cron);
        if (scheduler.checkExists(jobDetail.getKey())) scheduler.deleteJob(jobDetail.getKey());
        scheduler.scheduleJob(jobDetail, trigger);
    }

    /**
     * job detail 생성
     *
     * @param job
     * @param name
     * @param desc
     * @param map
     * @return
     */
    private JobDetail buildJobDetail(Class<? extends Job> job, String name, String desc, Map map) {
        JobDataMap jobDataMap = new JobDataMap();
        jobDataMap.putAll(map);

        return JobBuilder.newJob(job).withIdentity(name).withDescription(desc).usingJobData(jobDataMap).build();
    }

    /**
     * trigger 생성
     *
     * @param cron
     * @return
     */
    private Trigger buildCronTrigger(String cronExp) {
        return TriggerBuilder.newTrigger().withSchedule(CronScheduleBuilder.cronSchedule(cronExp)).build();
    }
}
