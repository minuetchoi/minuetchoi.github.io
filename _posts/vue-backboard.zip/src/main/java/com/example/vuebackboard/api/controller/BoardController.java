package com.example.vuebackboard.api.controller;

import com.example.vuebackboard.api.model.PagableResponse;
import com.example.vuebackboard.api.model.Request;
import com.example.vuebackboard.api.model.Response;
import com.example.vuebackboard.api.util.StringUtils;
import com.example.vuebackboard.api.service.BoardService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@Slf4j
public class BoardController {

    private final BoardService service;

    @GetMapping("/board/list")
    public PagableResponse boardList(HttpServletRequest httpServletRequest) {
        return service.getBoardList(StringUtils.getParameter(httpServletRequest));
    }

    @GetMapping("/board/{idx}")
    public Response getBoard(@PathVariable Long idx) {
        return service.getBoard(idx);
    }

    @PostMapping("/board")
    public Request create(@RequestBody Request request) {
        return service.create(request);
    }

    @PatchMapping("/board")
    public Request update(@RequestBody Request request) {
        return service.update(request);
    }

    @DeleteMapping("/board/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
