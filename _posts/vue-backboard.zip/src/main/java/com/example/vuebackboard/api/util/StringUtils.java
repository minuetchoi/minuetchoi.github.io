package com.example.vuebackboard.api.util;

import com.example.vuebackboard.api.model.Request;
import jakarta.servlet.http.HttpServletRequest;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

/**
 *
 * StringUtils
 *
 * @author Administrator
 * @version 1.0.0
 * @date 2023-01-18
 *
 **/
public class StringUtils extends org.apache.commons.lang3.StringUtils {

    private static String toProperCase(String s, boolean isCapital) {

        String rtnValue = "";

        if (isCapital) {
            rtnValue = s.substring(0, 1).toUpperCase() +
                s.substring(1).toLowerCase();
        } else {
            rtnValue = s.toLowerCase();
        }
        return rtnValue;
    }

    public static String toCamelCase(String s) {
        String[] parts = s.split("_");
        StringBuilder camelCaseString = new StringBuilder();

        for (int i = 0; i < parts.length; i++) {
            String part = parts[i];
            camelCaseString.append(toProperCase(part, (i != 0 ? true : false)));
        }

        return camelCaseString.toString();
    }

    public static Request getParameter(HttpServletRequest request) {
        Request valueObject = new Request();
        Enumeration<?> en = request.getParameterNames();
        while (en.hasMoreElements()) {
            String key = (String) en.nextElement();
            Object value = request.getParameter(key) == null ? request.getParameterValues(key)
                : request.getParameter(key);
            valueObject.put(key, value);
        }
        return valueObject;
    }

    public static List<Request> getParameters(HttpServletRequest request, String... columnNames) {
        List<Request> list = new ArrayList<Request>();
        if (columnNames == null || columnNames.length < 1) {
            Enumeration<?> enu = request.getParameterNames();
            List<String> params = new ArrayList<String>();
            while (enu.hasMoreElements()) {
                params.add((String) enu.nextElement());
            }
            columnNames = params.toArray(new String[params.size()]);
        }
        int maxCnt = request.getParameterValues(columnNames[0]).length;
        for (int idx = 0; idx < maxCnt; idx++) {
            list.add(new Request());
        }
        for (int idx = 0; idx < columnNames.length; idx++) {
            String[] temp = request.getParameterValues(columnNames[idx]);
            for (int j = 0; j < temp.length; j++) {
                list.get(j).setString(columnNames[idx], temp[j]);
            }
        }
        return list;
    }
}
