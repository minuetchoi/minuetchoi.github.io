package com.example.vuebackboard.api.config.mybatis;

import com.example.vuebackboard.api.config.mybatis.interceptor.PreparetInterceptor;
import com.example.vuebackboard.api.config.mybatis.interceptor.QueryInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MybatisConfig {

    @Bean
    public PreparetInterceptor preparetInterceptor() {
        return new PreparetInterceptor();
    }

    @Bean
    public QueryInterceptor queryInterceptor() {
        return new QueryInterceptor();
    }
}
