package com.example.vuebackboard.api.model;

import com.example.vuebackboard.api.util.StringUtils;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.map.ListOrderedMap;

@Data
@RequiredArgsConstructor
public class Response extends ListOrderedMap<Object, Object> {

    public Object put(Object key, Object value) {
        return super.put(StringUtils.toCamelCase((String) key), value);
    }
}
