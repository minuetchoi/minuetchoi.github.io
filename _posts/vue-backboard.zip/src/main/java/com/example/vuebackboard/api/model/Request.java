package com.example.vuebackboard.api.model;

import java.math.BigDecimal;
import java.util.*;
import java.util.Map.Entry;

public class Request extends LinkedHashMap<String, Object> {
    public Request() {
        super();
    }

    public void setColumn(String key, Object value) {
        this.put(key, value);
    }

    public Object getColumn(String key) {
        return this.get(key);
    }

    public String getString(String key) {
        Object value = this.get(key);
        if (value == null) {
            return null;
        } else {
            return value.toString();
        }
    }

    public void setString(String key, String value) {
        this.put(key, value);
    }

    public BigDecimal getNumber(String key) {
        Object value = this.get(key);
        BigDecimal decimal = BigDecimal.ZERO;
        try {
            decimal = new BigDecimal(value.toString());
        } catch (Exception e) {
            return BigDecimal.ZERO;
        }
        return decimal;
    }

    public void setNumber(String key, Object value) {
        BigDecimal decimal = BigDecimal.ZERO;
        try {
            decimal = new BigDecimal(value.toString());
            this.put(key, decimal);
        } catch (Exception e) {
            this.put(key, BigDecimal.ZERO);
        }
    }

    public String[] getColumnNames() {
        List<String> buffer = new ArrayList<String>();
        Set<Map.Entry<String, Object>> set = (Set<Entry<String, Object>>) this.entrySet();
        Iterator<Entry<String, Object>> iter = set.iterator();
        while (iter.hasNext()) {
            Entry<String, Object> entry = iter.next();
            buffer.add(entry.getKey());
        }
        return buffer.toArray(new String[buffer.size()]);
    }
}
